# Portfolio Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/yagoestevez/pen/oapQEJ](https://codepen.io/yagoestevez/pen/oapQEJ).

After 7 months of programming everyday and more than 30 projects built, this is last project I made for the FreeCodeCamp curriculum. 

It's been a great journey and I learnt A LOT of new stuff!